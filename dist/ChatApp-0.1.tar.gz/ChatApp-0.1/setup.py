#!/usr/bin/python3

from distutils.core import setup

setup(
    name='ChatApp',
    version= '0.1',
    py_modules = ['client','server'],
    author = 'vijaydeep sharma',
    author_email = 'vdsharma93@gmail.com',
    url='',
    description = '''this is simple application for chat and use Gtk for it GUI.
    this might contain bugs. so be careful.'''
    
)