This is simple chat app using GTK for it gui.
This may contain bugs, so be careful.

This is the tree structure of dir

chatApp/
├── client.py
├── dist
│   └── chat app-0.1.tar.gz
├── MANIFEST
├── __pycache__
│   ├── client.cpython-34.pyc
│   └── server.cpython-34.pyc
├── README.txt
├── README.txt~
├── server.py
├── setup.py
└── ui
    ├── about.glade
    ├── dialog.glade
    └── gui.glade

feel free to contact at vdsharma93@gmail.com
